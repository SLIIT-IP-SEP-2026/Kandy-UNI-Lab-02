public class IT26102558Lab2Q1 {
    public static void main(String[] args) {

        double perimeter = 100;

        double length = (perimeter / 2) * (4.0 / 7.0);
        double width = (3.0 / 4.0) * length;

        System.out.println("Length = " + length);
        System.out.println("Width = " + width);
    }
}